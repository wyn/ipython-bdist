"""IPython.kernel has been replaced by IPython.parallel.

The previous version of IPython's parallel library was located at this
location (IPython.kernel). It has been moved to the IPython.parallel
subpackage and has been refactored to use zeromq/pyzmq instead of twisted.

Please see INSERT URL for further details.
"""

raise ImportError(__doc__)
