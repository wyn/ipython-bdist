try:
    from pyparsing import *
except ImportError:
    from _pyparsing import *
