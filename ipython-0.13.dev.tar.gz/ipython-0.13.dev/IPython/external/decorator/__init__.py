try:
    from decorator import *
except ImportError:
    from _decorator import *
